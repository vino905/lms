package com.example.Final.LMS.util;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.example.Final.LMS.contoller.CoursesController;

public class FeesException extends CoursesController {
	public static ResponseEntity<String> Exceptional() {
		return new ResponseEntity<String>("Unsuccessful", HttpStatus.BAD_REQUEST);
	}
}