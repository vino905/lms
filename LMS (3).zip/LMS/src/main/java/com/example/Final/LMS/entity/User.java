package com.example.Final.LMS.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "user")
public class User {
	
	public User(int userId, String userName, String userEmail, String userMobile, String userOrganization,
			List<Courses> enrolledCourses, Admin admin) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userEmail = userEmail;
		this.userMobile = userMobile;
		this.userOrganization = userOrganization;
		this.enrolledCourses = enrolledCourses;
		this.admin = admin;
	}

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserMobile() {
		return userMobile;
	}

	public void setUserMobile(String userMobile) {
		this.userMobile = userMobile;
	}

	public String getUserOrganization() {
		return userOrganization;
	}

	public void setUserOrganization(String userOrganization) {
		this.userOrganization = userOrganization;
	}

	public List<Courses> getCourses() {
		return enrolledCourses;
	}

	public void setCourses(List<Courses> enrolledCourses) {
		this.enrolledCourses = enrolledCourses;
	}

	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int userId;
	
	@Column
	private String userName;

	@Column
	private String userEmail;
	
	@Column
	private String userMobile;

	@Column
	private String userOrganization;
	
    @OneToMany
	private List<Courses> enrolledCourses;
    
    @OneToOne
	private Admin admin;
    

    
}