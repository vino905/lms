package com.example.Final.LMS.contoller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Final.LMS.entity.Cart;
import com.example.Final.LMS.entity.Courses;
import com.example.Final.LMS.entity.User;
import com.example.Final.LMS.repositary.CartRepo;
import com.example.Final.LMS.repositary.CoursesRepo;
import com.example.Final.LMS.repositary.UserRepo;

@RestController
@RequestMapping("/cart")
public class CartController {

	@Autowired
	CartRepo crepo;

	@Autowired
	CoursesRepo courserepo;

	@GetMapping("/seecart/")
	public List<Cart> getData() {
		return crepo.findAll();
	}

	@GetMapping("/seecart/{id}")
	public List<Cart> findbyid(@PathVariable("id") int id) {
		List<Cart> carts = crepo.findAll();
		// List<Cart> c = carts.stream().filter(e->e.getUser().getUserId() ==
		// id).collect(Collectors.toList());
		List<Cart> newCart = new ArrayList<Cart>();
		for (Cart cartvar : carts) {
			if (cartvar.getUser().getUserId() == id) {
				newCart.add(cartvar);
			}
		}
		return newCart;
	}

	@PostMapping("/addtocart/")
	public void saveData(@RequestBody Cart obj) {
		crepo.save(obj);
		System.out.println(obj);
	}

	@DeleteMapping("/deletefromcart/{uid}/{cid}")
	public void deletecoursebyid(@PathVariable("uid") int userid, @PathVariable("cid") int courseid) {
		List<Cart> carts = crepo.findAll();
		for (Cart cartvar : carts) {
			if (cartvar.getUser().getUserId() == userid) {
				for (Courses coursevar : cartvar.getCourse()) {
					if (coursevar.getCourseId() == courseid) {
						courserepo.deleteById(courseid);
					}
				}
			}

		}
	}

}
