package com.example.Final.LMS.contoller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Final.LMS.entity.Admin;
import com.example.Final.LMS.entity.Courses;
import com.example.Final.LMS.entity.User;
import com.example.Final.LMS.repositary.AdminRepo;
import com.example.Final.LMS.repositary.CoursesRepo;
import com.example.Final.LMS.repositary.UserRepo;

@RestController
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	AdminRepo repo;
	
	@Autowired
	CoursesRepo crepo;
	
	@Autowired
	UserRepo urepo;

	@GetMapping("/seeadmin/")
	public List<Admin> getDataList() {
		return repo.findAll();
	}
	
	@GetMapping("/seeusers/")
	public List<User> getDataUsers() {
		return urepo.findAll();
	}
	
	@GetMapping("/seecourses/")
	public List<Courses> getData() {
		return crepo.findAll();
	}

	@PostMapping("/addcourse/")
	public void saveData(@RequestBody Courses obj) {
		crepo.save(obj);
	}
	
	@PostMapping("/addadmin/")
	public void saveData(@RequestBody Admin obj) {
		repo.save(obj);
	}
	
	  @DeleteMapping("/deleteuser/{id}")
	  public void deleteuserbyid(@PathVariable("id") int id)
	  {
		urepo.deleteById(id); 
	  }  
	  
	  
	@DeleteMapping("/deletecourse/{id}")
	public void deleteData(@PathVariable int id) {
		// list of all the student
		/*
		 * List<Student> studentList = studentRepo.findAll();
		 * 
		 * // iterating the student one by one for (Student stu : studentList) { //
		 * getting the list of address List<Address> addressList = stu.getAddresses();
		 * List<Address> addressListNew=new ArrayList<Address>(); for (Address ad :
		 * addressList) { if(ad.getId()==id) { // addressListNew.add(ad); } else {
		 * addressListNew.add(ad); } }
		 * 
		 * stu.setAddresses(addressListNew); studentRepo.save(stu); }
		 */
		crepo.deleteById(id);
	}
	
	@PutMapping("/editcourse/{id}")
	public ResponseEntity<Courses> updatecourse(@PathVariable("id") int id,@RequestBody Courses obj)  {
		Courses updatecourse = crepo.findById(id)
                .orElseThrow();
		updatecourse.setCourseName(obj.getCourseName());
		updatecourse.setCourseDescription(obj.getCourseDescription());
		updatecourse.setCourseLink(obj.getCourseLink());
		updatecourse.setCourseDuration(obj.getCourseDuration());
		updatecourse.setCoursePrice(obj.getCoursePrice());
		crepo.save(updatecourse);

        return ResponseEntity.ok(updatecourse);
	}
	
}
