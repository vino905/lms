package com.example.Final.LMS.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="admin")
public class Admin {

	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Admin(int adminId, String adminName, String adminEmail) {
		super();
		this.adminId = adminId;
		this.adminName = adminName;
		this.adminEmail = adminEmail;
//		this.courses = courses;
	}

	public int getAdminId() {
		return adminId;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getAdminEmail() {
		return adminEmail;
	}

	public void setAdminEmail(String adminEmail) {
		this.adminEmail = adminEmail;
	}

//	public List<Courses> getCourses() {
//		return courses;
//	}
//
//
//	public void setCourses(List<Courses> courses) {
//		this.courses = courses;
//	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int adminId;
	
	@Column
	private String adminName;
	
	@Column
	private String adminEmail;
	
//	@OneToMany
//	private List<Courses> courses;
	
}